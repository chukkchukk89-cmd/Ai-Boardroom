import Groq from 'groq-sdk';
import { LLMProvider, LLMRequest, LLMResponse } from './baseProvider';

export class GroqProvider implements LLMProvider {
  async generateContent(request: LLMRequest, apiKey: string): Promise<LLMResponse> {
    if (!apiKey) {
      throw new Error("Groq API Key is missing.");
    }
    try {
      const groq = new Groq({ apiKey });
      const response = await groq.chat.completions.create({
        messages: [
          { role: 'system', content: request.systemInstruction },
          { role: 'user', content: request.prompt },
        ],
        model: request.modelName,
        temperature: request.temperature,
      });

      return {
        text: response.choices[0]?.message?.content || '',
      };
    } catch (error) {
      console.error("Groq API Error:", error);
      throw new Error(`Groq API request failed for model ${request.modelName}.`);
    }
  }
}