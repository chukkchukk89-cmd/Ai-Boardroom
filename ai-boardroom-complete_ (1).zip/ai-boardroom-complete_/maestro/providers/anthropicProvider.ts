import Anthropic from '@anthropic-ai/sdk';
import { LLMProvider, LLMRequest, LLMResponse } from './baseProvider';

export class AnthropicProvider implements LLMProvider {
  async generateContent(request: LLMRequest, apiKey: string): Promise<LLMResponse> {
    if (!apiKey) {
      throw new Error("Anthropic API Key is missing.");
    }
    try {
      const anthropic = new Anthropic({ apiKey });
      const response = await anthropic.messages.create({
        model: request.modelName,
        max_tokens: 2048, // A reasonable default
        system: request.systemInstruction,
        messages: [
          { role: 'user', content: request.prompt },
        ],
        temperature: request.temperature,
      });

      return {
        text: response.content.map(block => block.text).join('\n'),
      };
    } catch (error) {
      console.error("Anthropic API Error:", error);
      throw new Error(`Anthropic API request failed for model ${request.modelName}.`);
    }
  }
}