// maestro/providers/geminiProvider.ts

import { GoogleGenAI } from '@google/genai';
import { LLMProvider, LLMRequest, LLMResponse } from './baseProvider';

export class GeminiProvider implements LLMProvider {
  async generateContent(request: LLMRequest, apiKey: string): Promise<LLMResponse> {
    if (!apiKey) {
      throw new Error("Gemini API Key is missing.");
    }
    try {
      const ai = new GoogleGenAI(apiKey);
      const model = ai.getGenerativeModel({ model: request.modelName, systemInstruction: request.systemInstruction });
      
      const result = await model.generateContent(request.prompt);

      // Normalize the response to the standard format
      return {
        text: result.response.text(),
        functionCalls: result.response.functionCalls(),
      };
    } catch (error) {
      console.error("Gemini API Error:", error);
      // Re-throw a standardized error if needed, or handle it here
      throw new Error(`Gemini API request failed for model ${request.modelName}.`);
    }
  }
}