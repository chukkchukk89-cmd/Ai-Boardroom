import OpenAI from 'openai';
import { LLMProvider, LLMRequest, LLMResponse } from './baseProvider';

export class DeepSeekProvider implements LLMProvider {
  async generateContent(request: LLMRequest, apiKey: string): Promise<LLMResponse> {
    if (!apiKey) {
      throw new Error("DeepSeek API Key is missing.");
    }
    try {
      const openai = new OpenAI({
        apiKey: apiKey,
        baseURL: "https://api.deepseek.com/v1",
      });
      const response = await openai.chat.completions.create({
        messages: [
          { role: 'system', content: request.systemInstruction },
          { role: 'user', content: request.prompt },
        ],
        model: request.modelName,
        temperature: request.temperature,
      });

      return {
        text: response.choices[0]?.message?.content || '',
      };
    } catch (error) {
      console.error("DeepSeek API Error:", error);
      throw new Error(`DeepSeek API request failed for model ${request.modelName}.`);
    }
  }
}