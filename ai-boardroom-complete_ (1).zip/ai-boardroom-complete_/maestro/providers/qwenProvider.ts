import OpenAI from 'openai';
import { LLMProvider, LLMRequest, LLMResponse } from './baseProvider';

export class QwenProvider implements LLMProvider {
  async generateContent(request: LLMRequest, apiKey: string): Promise<LLMResponse> {
    if (!apiKey) {
      throw new Error("Qwen (DashScope) API Key is missing.");
    }
    try {
      const openai = new OpenAI({
        apiKey: apiKey,
        baseURL: "https://dashscope.aliyuncs.com/compatible-mode/v1",
      });
      const response = await openai.chat.completions.create({
        messages: [
          { role: 'system', content: request.systemInstruction },
          { role: 'user', content: request.prompt },
        ],
        model: request.modelName,
        temperature: request.temperature,
      });

      return {
        text: response.choices[0]?.message?.content || '',
      };
    } catch (error) {
      console.error("Qwen (DashScope) API Error:", error);
      throw new Error(`Qwen (DashScope) API request failed for model ${request.modelName}.`);
    }
  }
}