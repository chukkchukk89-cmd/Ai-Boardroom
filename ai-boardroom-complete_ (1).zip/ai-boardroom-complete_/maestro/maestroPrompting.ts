// maestro/maestroPrompting.ts
import { Agent, MaestroPromptContext } from '../types';
import { constructBoardroomPrompt, buildProjectTurnPrompt, constructSandboxPrompt } from '../prompts';
import { LLMProvider, LLMRequest, GeminiProvider, UnsupportedProvider, LLMResponse, AnthropicProvider, GroqProvider, DeepSeekProvider, QwenProvider } from './providers';
import { GoogleGenAI, Modality } from '@google/genai';

export interface AgentLLMResponse extends LLMResponse {
    audio?: string; // base64 encoded audio
}

const getProviderForAgent = (agent: Agent): LLMProvider => {
  switch (agent.model.provider) {
    case 'Gemini':
      return new GeminiProvider();
    case 'Anthropic':
      return new AnthropicProvider();
    case 'Groq':
      return new GroqProvider();
    case 'DeepSeek':
      return new DeepSeekProvider();
    case 'Qwen':
      return new QwenProvider();
    default:
      console.warn(`Unknown provider: ${agent.model.provider}. Defaulting to Gemini.`);
      return new GeminiProvider();
  }
};

const getPromptBuilder = (mode: MaestroPromptContext['mode']): ((context: MaestroPromptContext) => string) => {
    switch (mode) {
        case 'Boardroom': return constructBoardroomPrompt;
        case 'Project': return buildProjectTurnPrompt;
        case 'SocialSandbox': return constructSandboxPrompt;
        case 'Comparison': return constructBoardroomPrompt; // Fallback
        default: return constructBoardroomPrompt;
    }
}

const generateSpeech = async (text: string, voice: string, apiKey: string): Promise<string | undefined> => {
    if (!apiKey) {
        console.error("Cannot generate speech: Gemini API Key is not provided.");
        return undefined;
    }
    try {
        const ai = new GoogleGenAI(apiKey);
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash-preview-tts",
            contents: [{ parts: [{ text }] }],
            config: {
                responseModalities: [Modality.AUDIO],
                speechConfig: {
                    voiceConfig: {
                        prebuiltVoiceConfig: { voiceName: voice },
                    },
                },
            },
        });
        
        const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
        return base64Audio;
    } catch (error) {
        console.error("Error generating speech:", error);
        return undefined;
    }
};

export const generateAgentResponse = async (
  context: MaestroPromptContext,
  prompt: string,
  temperature: number,
  apiKey: string, // API key is now a required parameter
): Promise<AgentLLMResponse> => {
  const provider = getProviderForAgent(context.agent);
  const promptBuilder = getPromptBuilder(context.mode);
  const systemInstruction = promptBuilder(context);

  const request: LLMRequest = {
    systemInstruction,
    prompt,
    temperature,
    modelName: context.agent.model.modelName,
    tools: context.tools,
  };
  
  const textResponse = await provider.generateContent(request, apiKey, context);

  // If the agent has a voice and the text response was successful, generate audio.
  // Note: This assumes the voice provider is Gemini. A more robust solution would check the voice provider.
  if (context.agent.voice && textResponse.text) {
      const audio = await generateSpeech(textResponse.text, context.agent.voice, apiKey);
      return { ...textResponse, audio };
  }

  return textResponse;
};

export const constructMaestroPrompt = (context: MaestroPromptContext): string => {
  const promptBuilder = getPromptBuilder(context.mode);
  return promptBuilder(context);
};