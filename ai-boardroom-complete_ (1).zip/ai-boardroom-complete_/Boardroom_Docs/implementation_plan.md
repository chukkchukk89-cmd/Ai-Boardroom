# AI Boardroom: Implementation & Alignment Plan

## 1. Overview

This document is the official, step-by-step technical guide for aligning the current codebase with the "v1.0 Compendium." It translates our "Rewritten Alignment Resolution" into a prioritized, logical build plan.

## 2. Phase 1: Secure the Foundation & Fulfill Core Promises (P0 - P1)

This phase is paramount. It addresses critical security vulnerabilities and transforms currently simulated features into functional realities.

### Task 1.0 (P0): Implement Secure API Key Proxy

*   **Goal:** Fix the client-side API key exposure.
*   **Architecture:** Create a single, lightweight serverless function to act as a secure proxy.
*   **Implementation Steps:**
    *   **Backend:** Create a new serverless function (e.g., `/api/llm-proxy.ts` on Vercel or Netlify).
        *   This function reads the real API keys from server-side environment variables (e.g., Vercel Project Settings).
        *   It reads the POST body from the client (which contains the provider, prompt, and config).
        *   It uses a switch statement or if/else block to identify the provider (gemini, anthropic, etc.).
        *   It makes the actual API call from the server (using its secure keys) to the correct LLM endpoint.
        *   It streams the LLM's response directly back to the client.
    *   **Client-Side:** Modify all API call functions (e.g., in `llm.ts` or `maestroPrompting.ts`) to send their requests to the new `/api/llm-proxy` endpoint instead of the public LLM URLs.
        *   **Specific Modification:** Modify `maestro/maestroPrompting.ts`'s `getProviderForAgent` function to route all LLM API calls through this new proxy endpoint, ensuring no direct client-side calls to LLM provider APIs.
*   **Compendium Alignment:** This fulfills the "Zero-Data-Storage" promise, as our proxy only handles keys and never stores user data.

### Task 1.1: Make the RAG System Real (Client-Side)

*   **Goal:** Replace the simulated RAG service with a real, client-side vector search.
*   **Implementation Steps:**
    *   **Install Libraries:** `npm install @xenova/transformers voy-search pdfjs-dist mammoth` (Note: `pdf.js` is typically `pdfjs-dist` for npm).
    *   **File Handling (`FileUploader.tsx`):**
        *   In the file upload handler, check the file extension.
        *   For `.pdf`: Use `pdfjs-dist`'s `getDocument` and `getTextContent` to extract the raw text.
        *   For `.docx`: Use `mammoth.js`'s `extractRawText` to extract the raw text.
        *   For `.txt`: Read as plain text.
        *   Pass this extracted text to the RAG service.
    *   **RAG Core (`rag/vectorUtils.ts`):**
        *   **Embeddings:** Modify `createEmbedding` in `rag/vectorUtils.ts` to use `transformers.js` (e.g., `Xenova/all-MiniLM-L6-v2` model) to generate real vector embeddings from the text.
        *   **Search:** Modify `queryVectorStore` to initialize `voy-search` with these embeddings. Use `voy.search(queryEmbedding, 5)` to get the 5 most relevant chunks of text.
*   **Compendium Alignment:** This makes sections 7-1 (L3) and 7-2 fully functional and accurate.

### Task 1.2: Implement the Full Voice Promise (STT)

*   **Goal:** Enable Speech-to-Text for user input.
*   **Implementation Steps:**
    *   **UI:** Add a "Microphone" icon button to the user input component (`UserInputBar.tsx`).
    *   **Logic:**
        *   On button click, check for `window.SpeechRecognition || window.webkitSpeechRecognition` and initialize it.
        *   Set `recognition.interimResults = true` to get live feedback.
        *   Use the `recognition.onresult` event to update the text input field's state with the transcribed text.
        *   Call `recognition.start()` on button press and `recognition.stop()` on a second press or after a pause.
*   **Compendium Alignment:** Fulfills section 8-1.

### Task 1.3: Implement the "Frugal" Promises

*   **Goal:** Activate the "Smart-Cache" and "Token Firewall" to save costs and protect users.
*   **Implementation Steps:**
    *   **"Smart-Cache":**
        *   **Install:** `npm install object-hash` (or a similar fast-hashing library).
        *   **Logic (in `maestroPrompting.ts` or a new `llmService.ts`):** Before making an API call, create a unique hash: `const requestHash = hash({ provider, prompt, config });`.
        *   Check a global `Map` or `lru-cache`. If `cache.has(requestHash)`, return the cached response without making an API call.
        *   On a successful API response, store it: `cache.set(requestHash, response);`.
        *   **Cache Invalidation:** Ensure the cache is cleared upon starting a new session, loading a checkpoint, or manual user action to guarantee fresh responses when desired.
    *   **"Token Firewall":**
        *   **Install:** `npm install js-tiktoken` (a lightweight tokenizer).
        *   **Logic (in `maestroPrompting.ts` or `llmService.ts`):** Before making an API call, estimate the prompt's size: `const tokens = getEncoding('cl100k_base').encode(prompt);`.
        *   If `tokens.length` exceeds a user-configurable limit (e.g., `TOKEN_LIMIT = 150` for agent responses), throw an error.
        *   Catch this error in the UI and display a user-friendly message (do not use `alert()`).
*   **Compendium Alignment:** Fulfills section 8-2.

## 3. Phase 2: Implement the "Magic" — Unique Mode Logic (P2 Actions)

With the foundation secure, we now build the distinct, user-facing features that define and differentiate each application mode.

### Task 2.0: Build "Comparison Mode" (Mode 4)

*   **Goal:** Implement the placeholder `ComparisonMode.tsx` component.
*   **Implementation Steps:**
    *   **UI:** Build a split-panel UI within `ComparisonMode.tsx` with two distinct areas. Each area should contain its own `SessionLoggingPanel` component to display independent conversation flows.
    *   **Logic:**
        *   This mode will require two independent sets of agent configurations (e.g., `configA`, `configB`).
        *   Implement logic to run two simulation loops concurrently (e.g., `runSimulation(configA)`, `runSimulation(configB)`).
        *   Pipe the log streams from each simulation to their respective UI panels.
        *   **Scorecard:** Add a simple "Scorecard" component at the end that compares the textual outputs, total tokens used, and estimated API cost for A vs. B, leveraging data from the "Token Firewall" and "Smart-Cache."
*   **Compendium Alignment:** Fully realizes Part 4-4.

### Task 2.1: Make "Boardroom Mode" Unique

*   **Goal:** Implement the "Devil's Advocate" and "Validation Icons" features.
*   **Implementation Steps:**
    *   **"Devil's Advocate" Logic (in `runBoardroomSimulation`):**
        *   Add logic to check if any agent in the configuration has the role `devil's-advocate`.
        *   If one exists, ensure its turn is strategically inserted after a key proposal is made, prompting it for critical analysis.
    *   **"Validation Icons" (Simplified Logic):**
        *   **Prompt Engineering:** Modify the "Boardroom Mode" system prompt for agents. Instruct all agents: "When it is your turn, you must begin your response by explicitly stating your agreement, disagreement, or concerns with the previous agent's main point. For example: 'I agree with the previous point...' or 'I have a concern about...'"
        *   **UI (`SessionLoggingPanel.tsx`):** When rendering a message, parse its text for these keywords.
        *   If `msg.text.startsWith("I agree")`, display a ✅ icon.
        *   If `msg.text.startsWith("I disagree")` or `msg.text.startsWith("I have a concern")`, display a ⚠️ icon.
*   **Compendium Alignment:** Fulfills section 4-1.

### Task 2.2: Make "Social Sandbox" Unique

*   **Goal:** Implement the "Participant vs. Observer" roles.
*   **Implementation Steps:**
    *   **Agent Config:** Add an `isObserver: boolean` property to the `AgentConfig` interface.
    *   **UI:** Add a toggle (e.g., an "eye" icon) for this property in the `AgentCreationPanel`.
    *   **Logic (in `runSocialSandboxSimulation`):** Before starting the turn-based loop, filter the agents: `const activeAgents = agents.filter(a => !a.isObserver);`. Use this `activeAgents` list for the simulation.
*   **Compendium Alignment:** Fulfills section 4-2.

## 4. Phase 3: Evolve the Intelligence — The "Living" AI (P3 Actions)

The app is now fully functional. This phase makes the AI smarter through enhanced memory, learning, and dynamic capabilities.

### Task 3.0: Implement Checkpointing & L2 Memory

*   **Goal:** Allow users to save, load, and re-use entire sessions with persistence and long-term memory.
*   **Implementation Steps:**
    *   **Install:** `npm install crypto-js` (or a similar AES library).
    *   **Save/Load Logic (`utils/archive.ts`):**
        *   `saveSession(state)`: Takes the entire app state, `JSON.stringifys` it, encrypts it using `AES.encrypt(...)`, and saves it to `localStorage` under a unique key (e.g., `session_timestamp`).
        *   `loadSession(sessionId)`: Reads the encrypted string from `localStorage`, decrypts it using `AES.decrypt(...)`, `JSON.parses` it, and returns the full state object.
    *   **Archive UI (`ArchivePanel.tsx` - New Component):**
        *   Create a new panel for the "Archive" tab.
        *   It should read all `session_*` keys from `localStorage`, decrypt their metadata (like session name/date), and display them in a list.
        *   Each item should have a "Load" button (calls `loadSession` and re-hydrates the app) and a "Delete" button.
    *   **L2 Memory (RAG Integration):**
        *   Modify the RAG service so that when a session is loaded, the user has an option to also "Include this session's text in the RAG context." This will involve processing the `sessionLog` of the loaded session through the RAG pipeline.
*   **Compendium Alignment:** Fulfills sections 2-4, 7-1 (L2), and 7-3.

### Task 3.1: Enable "Agent Evolution" & "Maestro's Conscience"

*   **Goal:** Make agents "learn" from past work and make Maestro a better moderator.
*   **Implementation Steps:**
    *   **"Agent Evolution":**
        *   After a simulation ends, call Maestro using the `SUMMARIZE_AGENT_LESSONS` prompt for each agent.
        *   Take the resulting "lesson" (e.g., "I learned that for financial analysis, I should always check X") and save it back into that agent's `agentMemory` property (e.g., in `localStorage` or as part of the `AgentConfig` that gets saved with checkpoints).
        *   Ensure this `agentMemory` is part of the `AgentConfig` so it is saved/loaded with the session and included in future prompts for that agent.
    *   **"Maestro's Conscience":**
        *   In the `runBoardroomSimulation` loop, add a simple check: `if (checkForDisagreement(lastTwoTurns)) { ... }`.
        *   `checkForDisagreement` can be a simple function that checks if one agent expressed agreement and the next expressed disagreement, or if sentiment analysis indicates high tension.
        *   If true, pause the normal agent rotation and inject a turn from Maestro, using the `DISCUSSION_MODERATION` prompt to guide the conversation back on track.
*   **Compendium Alignment:** Fulfills sections 2-3 and 3-3.

### Task 3.2: Fully Implement Agent "Tools"

*   **Goal:** Allow agents to run code, search Google, etc.
*   **Implementation Steps:**
    *   **Logic (in `maestroPrompting.ts` / `runSimulation`):**
        *   When an LLM response includes a `functionCall` or `toolCall` object:
            *   **PAUSE** the simulation loop.
            *   Parse the `toolName` (e.g., `googleSearch`) and `toolArgs` (e.g., `{ query: "..." }`).
            *   Call a new `executeTool(toolName, toolArgs)` function. This function uses a switch statement to run the actual tool (e.g., make a Google Search API call via the secure proxy).
            *   Get the `toolResult` (the text from the search).
            *   **RESUME** the simulation by calling the LLM again, but this time, pass the `toolResult` back to it so the agent can react to the information it found.
*   **Compendium Alignment:** Fulfills section 3-2 (Layer 3).

## 5. Phase 4: Compendium & Documentation Alignment (Documentation Focus)

This phase ensures the project's documentation accurately reflects the realistic current and near-future project scope.

### Task 4.0: Update Compendium Appendices

*   **Goal:** Ensure all Appendix sections are aligned with the implementation plan and current project status.
*   **Implementation Steps:**
    *   **LangGraph:** Update Appendix [A-3] to state: "The system uses a Custom State Machine built on prompt-engineering principles, not a third-party library, to ensure lightweight, client-side operation."
    *   **Tech Stack:** Update Appendix [C-1] to remove all mentions of "React Native" and "Ionic." State the stack is "React, Vite, and Tailwind, deployed as a Progressive Web App (PWA)."
    *   **Security (ReBAC):** Update Appendix [B-1] to clarify: "A full technical ReBAC framework is not implemented. Instead, 'Role-Based Responsibilities' are strictly enforced via prompt engineering and our Custom State Machine, ensuring agents operate within their defined roles."

---

## 6. Summary of Immediate Next Steps for Development:

*   **Compendium Modification (Low effort, high impact):** Begin updating the Compendium's sections on "Zero-Infrastructure" (now "Zero-Data-Storage"), "Tech Stack," and "Security" to immediately reflect this realistic and powerful strategy.
*   **Begin Phase 1 Tasks:**
    1.  **Critical priority:** Initiate development and integration of the serverless API key proxy.
    2.  **Parallel development:** Concurrently, start implementing the real RAG system (client-side PDF/DOCX parsing and client-side vector search) and the browser-native STT integration.

---

This phased plan ensures responsible development, addresses critical security, and provides a clear, achievable roadmap to fully aligning a robust, free-tier product with your compelling vision.
