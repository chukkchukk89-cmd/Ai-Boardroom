The AI Boardroom: A Compendium
The Ultimate Reference for a New Era of Collaborative Intelligence v1.0 (Saturday, October 25, 2025)

## Glossary of Terms

Before we begin, here are a few simple definitions for the key concepts we'll be discussing.

*   **Maestro:** The "conductor" or "project manager" AI. It's the central brain that guides the conversation, assigns tasks, and ensures the team stays on track.
*   **Agent:** The "specialist" AI team members. Each one has a specific role, personality, and skillset (e.g., "Financial Analyst," "Creative Writer," "Devil's Advocate").
*   **Tri-Cameral:** Our name for the "three-panel" layout of the app. It's designed to separate your preparation (Workshop), your performance (Main Chamber), and your review (Archive).
*   **RAG (Retrieval-Augmented Generation):** The "smart memory" that allows AI agents to read, reference, and "cite" documents—like your uploaded files or past conversations.
*   **Executor:** A special type of agent used in "Project Mode." Its job isn't just to talk about a task, but to do it.
*   **Zero-Data-Storage:** Our core security promise. It means your private conversation data and files are never stored on our servers.
*   **PWA (Progressive Web App):** The technology our app uses. It allows you to "install" the app on your desktop or mobile device directly from the browser, and it enables powerful offline capabilities.

## How to Read This Document

This compendium is your guide to the "what," "why," and "how" of the AI Boardroom. It's written in plain, conversational language to describe the fully-featured v1.0 application.

When we mention a highly technical concept (like the specific math for an equation or the technical stack), we add an index tag like [A-1] or [B-2]. These tags refer to the Appendix at the end of this document, where you can find the "deeper dive" technical details.

## Part 1: The Vision & The 'Why'

### 1-1. The Big Idea: A Collaborative Partner, Not a Tool

What is the AI Boardroom?
It's not just another chatbot. It's a team of AI specialists—a "boardroom"—with you as the director.

You don't just give it a command and get a single response. You present a goal, and a team of agents collaborates to achieve it. You can watch them debate, build on each other's ideas, catch each other's mistakes, and build a comprehensive solution, all guided by the central "Maestro" AI.

It's a shift from "command-and-control" to "collaborate-and-create."

### 1-2. The Problems We Solve (Pain Points)

The AI Boardroom is designed to solve real-world problems that single-AI tools can't.

*   For the "Manager": Stops the feeling of "herding cats." Instead of you having to copy-paste information between different tools, Maestro handles the delegation and synthesis.
*   For the "Creative": Solves the "blank page" problem. You can brainstorm with a team of diverse thinkers in the "Social Sandbox" to get an idea off the ground.
*   For the "Executive": Breaks down "information silos." You can have a "Finance Agent" and a "Marketing Agent" debate a new product launch, giving you a 360-degree view before the human meeting.

### 1-3. Who Is This For? (Practical Application)

*   "Alex, the Project Manager": Alex uses "Project Mode" to turn a vague goal into a complete project plan, executed by "Executor" agents, all while they watch.
*   "Sarah, the Creative Director": Sarah uses the "Social Sandbox" to simulate a focus group for a new ad campaign, getting instant, high-fidelity feedback.
*   "David, the C-Suite Executive": David uses "Boardroom Mode" to "war-game" a new business strategy, using the "Devil's Advocate" agent to find every flaw before it costs real money.

### 1-4. The "Zero-Data-Storage" Promise

This is the most important foundation of the AI Boardroom. It is our core security and privacy guarantee.

*   **What it means:** Your conversation data, your private documents, and your session files are never stored on our external servers. Period.
*   **How it works:** All of your data operations occur locally in your browser. We utilize a lightweight, secure proxy solely to safeguard your AI API keys from being exposed. Your unique data processing remains private and direct between your browser and the AI providers, without persisting on our servers.

## Part 2: Maestro — The Conductor

### 2-1. What is Maestro?

If the agents are the "orchestra," Maestro is the "conductor." It's the central brain, the strategist, and the moderator.

Maestro's job is not to do the work, but to ensure the work gets done right. It reads your main goal, decides the best "mode" to use, and then guides the agent team to the finish line.

### 2-2. The Superprompt: From Intent to Action

When you give the Boardroom a goal, Maestro takes your intent and expands it into a "Superprompt"—a complete "plan of action." This plan tells each agent its specific role, its goals, and the rules of the conversation. It's a living document that Maestro updates as the conversation evolves.

### 2-3. How Maestro Communicates

Maestro has two key behaviors that make the conversation feel intelligent:

1.  **The "Conductor's Baton":** Maestro decides who speaks and when. It's not a simple round-robin. It "points" to the most relevant agent based on the last thing that was said.
2.  **The "Conscience":** Maestro actively listens for consensus and conflict. If a debate goes off-track or two agents are in a logical stalemate, Maestro actively steps in (using its `DISCUSSION_MODERATION` logic) to moderate, resolve the conflict, and get the team back on track.

### 2-4. "Checkpointing": Never Lose Your Place

The system is built with a powerful "checkpoint" feature. At any time, you can save your entire session—all agent configurations, the full message history, and all private memories. You can then load this session later from the "Archive" panel, resuming exactly where you left off.

## Part 3: The Agents — The Orchestra

### 3-1. The Multi-LLM Philosophy

Why have a team of different AI models? Simple: you wouldn't use a hammer to paint a picture.

Different AI models ("brains") have different strengths. The Boardroom lets you build a team that uses the right brain for the right job. This allows the team to:

*   **Catch Errors:** A "logic" agent can correct a "creative" agent's factual mistake.
*   **Build Consensus:** You get a more reliable answer when three different "minds" all arrive at the same conclusion.
*   **Achieve "Synthesis":** The real magic happens when the agents combine their strengths to create a solution better than any one of them could have alone.

### 3-2. The "Genetics" of an Agent (via "The Workshop" Panel)

In "The Workshop" panel, you build your agents. Each one is made of three "genetic" layers:

1.  **Layer 1: The "Brain" (The LLM Model):** This is the "engine." You choose the foundational model you want the agent to use.
2.  **Layer 2: The "Persona" (The Personality):** This is the "character." Is it a formal, data-driven "Analyst"? A skeptical "Devil's Advocate"?
3.  **Layer 3: The "Skills" (The Tools):** This is what the agent can do. Each agent has a "toolbelt." You can give them tools like `googleSearch` for real-time data, or a `codeInterpreter` to test a theory.

### 3-3. Agent Evolution

Agents truly evolve. They aren't static. After a simulation concludes, Maestro works with each agent to "summarize its lessons learned" (`SUMMARIZE_AGENT_LESSONS`). This "lesson" is then saved to the agent's private memory. The next time you use that agent, it brings that experience with it, becoming "sharper" and more aligned with its role over time.

## Part 4: The Four Modes — The Performance

The AI Boardroom has four distinct "modes," each designed for a specific kind of work.

### 4-1. Mode 1: The "Boardroom" (Strategic Consensus)

*   **The Goal:** To "war-game" a complex idea and find the best possible answer.
*   **The Logic ("Sequential Criticality"):** In this mode, no idea goes unchallenged. Each agent is prompted to build upon, critique, or validate the statement made by the previous agent.
*   **Key Features:**
    *   **"Devil's Advocate":** You can designate an agent with this role, and Maestro ensures it is strategically prompted to find flaws and risks.
    *   **"Validation Icons" (✅❌⚠️):** You see a clear, visual indicator next to each statement. Maestro parses the team's reactions (e.g., "I agree," "I have concerns") to assign an icon, letting you see the state of consensus at a glance.

### 4-2. Mode 2: The "Social Sandbox" (High-Fidelity Simulation)

*   **The Goal:** To simulate "real-world" conversations and creative brainstorming.
*   **The Logic ("Persona-Driven"):** All rules of consensus are off. This mode is for pure, creative roleplay. The only goal is for agents to stay "in character."
*   **Key Features:**
    *   **"Participant vs. Observer" Roles:** You can jump into the conversation yourself, or you can set any agent to be a silent "Observer" (`isObserver: true`) to watch how the others interact without them.

### 4-3. Mode 3: The "Project" (Map-Reduce Execution)

*   **The Goal:** To turn a large, complex task into a finished product.
*   **The Logic ("Splitting the Work"):** Maestro acts as a "Project Manager." It takes your big goal and "splits the work" into many small, parallel tasks. It assigns these tasks to "Executor" agents.
*   **Key Features:**
    *   **"Executor Bots":** These agents don't just talk; they work. You see them "pulse" with a blue glow as they execute their tasks.
    *   **"Synthesis":** After the Executors are done, Maestro (or a "Manager" agent) lights up, gathers all the small pieces, and "synthesizes" them into the final, complete deliverable.

### 4-4. Mode 4: The "Comparison Lab" (A/B Analysis)

*   **The Goal:** To scientifically test two different ideas against each other.
*   **The Logic ("Dual-Path"):** This mode runs two separate, parallel conversations to get an objective, unbiased evaluation.
*   **Key Features:**
    *   **"Split-Screen" View:** You see both conversations unfold side-by-side in real-time. (e.g., "Version A" vs. "Version B" of a marketing email).
    *   **"Data Scorecard":** At the end, Maestro provides a final scorecard comparing the two options on key metrics like cost, speed, and accuracy.

## Part 5: The Interface — Your "Tri-Cameral" Hub

The app is organized into a "Tri-Cameral" or "three-panel" layout. We designed it this way because your workflow isn't one-dimensional. You need a place to prepare, a place to work, and a place to review.

### 5-1. Panel 1: "The Workshop" (Left Panel)

This is your "command center." It's where you do all your preparation.

*   Build and configure your agents.
*   Choose your "Mode" for the session.
*   Load the documents you want the AI to read.

### 5-2. Panel 2: "The Main Chamber" (Center Panel)

This is the "stage." It's the main event, where the conversation or project simulation happens. You can watch the agents collaborate, or jump in and participate yourself.

### 5-3. Panel 3: "The Archive" (Right Panel)

This is your "living library." It's where you access all your historical data.

*   Search past conversations.
*   Browse, load, and delete your saved "Checkpoint" sessions.
*   Manage your saved documents.

## Part 6: The Conversation Engine — The Music

How do we make the conversation feel so "real" and "authentic"? It's a combination of smart logic and powerful features.

### 6-1. The "Playbook" for Conversation (Our Custom State Machine)

Our system uses a custom, highly flexible state machine to orchestrate the chat. Think of it as a "smart map" or "playbook" for the conversation, rather than a rigid script. This allows the conversation to be incredibly dynamic, responsive, and resilient, all while ensuring lightweight client-side operation.
(For a conceptual overview, see Appendix [A-3].)

### 6-2. How Bots "Listen" & Users Can "Interject"

Agents use "Shadow Listening" to "hear" what other agents are saying in real-time. This is what allows them to build on each other's ideas or even "interject" naturally. This same logic allows you to interject at any time, and Maestro will pause the flow to listen to you.

### 6-3. The "Weighted Response System": Art Meets Science

How does Maestro really decide what to say or do next? It uses a "Weighted Response System" that's like a recipe with five core "ingredients."

1.  **What you just asked for (User Objective):** This gets the most weight.
2.  **The overall "game plan" (Super Prompt):** Is this aligned with the mode we're in?
3.  **Your uploaded files (Contextual RAG):** Is there a key fact in a PDF?
4.  **The conversation so far (Global Summary):** Are we staying on topic?
5.  **What the other bots are saying (Cross-Agent Consistency):** Are we building consensus?

Maestro balances these "ingredients" every single turn to produce the most relevant, intelligent, and context-aware response.
(For the exact percentages and the math, see Appendix [A-1].)

## Part 7: The Memory & The Archive

An AI is only as smart as its memory. We've built a powerful, three-layer memory system to give your agents a "mind."

### 7-1. The 3 Layers of Memory (The "Mind")

1.  **Layer 1: "Bot Working Memory" (The "Now"):** This is the short-term memory of what's happening right now.
2.  **Layer 2: "Manager Long-Term Memory" (The "Archive"):** This is the "smart" archive of all your past, saved sessions. Using RAG, Maestro can search this history for relevant context from a project you did six months ago.
3.  **Layer 3: "Contextual RAG" (The "Files"):** This is the memory layer that contains your uploaded documents.

### 7-2. The "Supporting Materials Handler"

This is a critical security and cost-saving feature. When you upload a PDF or DOCX file, the app uses built-in, client-side tools (`pdf.js`, `mammoth.js`) to extract the text safely in your browser.

Your private file is never uploaded to a server. The app extracts the text, creates a local vector embedding, and feeds that "grounding summary" directly to the agents as context. It's fast, free, and completely secure.

### 7-3. The "Convo Log" & "Archive" Panels (The "Library")

The "Archive" panel is your user-friendly window into the AI's "mind." You can use it to search, review, and manage all three layers of memory, making your entire history a usable asset. This is where you browse, load, and delete your saved "Checkpoint" sessions.

## Part 8: The Foundation — Safe, Smart, & Secure

Everything we've built is on a foundation designed for security and efficiency.

### 8-1. The Voice of the Boardroom (TTS/STT)

You can interact with the Boardroom using both text-to-speech (TTS) and speech-to-text (STT). We use the browser's native, high-performance `SpeechRecognition API` to let you give commands with your voice, and you can hear the agents' "vocal personas" speak their responses.

### 8-2. Smart & Frugal: Our Cost-Saving Features

Our "Zero-Data-Storage" model already saves you money. But we go even further.

*   **The "Smart-Cache":** Our system aggressively caches responses. Before making an API call, it checks a local cache to see if the exact same request was made recently, preventing redundant calls and saving you money.
*   **The "Token Firewall":** We use a client-side "token counter" that warns you before sending a request that might be unusually large or expensive. This gives you full control over your budget.

### 8-3. Your Data, Your Rules: Our "Zero-Data-Storage" Security

We'll say it one more time because it is the most important part of our design.

Your data is yours. Period.

The "Zero-Data-Storage" model means we are never in the middle. The app creates a direct, encrypted connection from your browser to the AI (via our secure key proxy). Furthermore, all sensitive session data you choose to save locally in your "Archive" is encrypted using AES-256 standards before it's stored in your browser.
(For a full list of security frameworks, see Appendix [B-1].)

## Part 9: The Journey — Now & Next

### 9-1. Your First Day: The Onboarding Experience

We are building a guided "first-time use" walkthrough. Maestro itself will be your guide, introducing you to the "Tri-Cameral" layout, helping you build your first agent, and running your first simulation.

### 9-2. The Roadmap: From Foundation to Polish

This v1.0 is built on a clear, 5-phase development plan that takes us from the core foundations to a fully polished, enterprise-ready product.
(For the full 18-week, 5-phase plan, see Appendix [A-2].)

### 9-3. The Future: What We're Dreaming Of

This is just the beginning. We're already dreaming of what's next:

*   Agents that can use tools on each other.
*   Agents that can create and assign new agents on their own.
*   Deeper integration with 3D visualization.

The goal is to create a system that doesn't just answer your questions, but helps you find the questions you didn't even know to ask.

## Appendix: Deeper Dives [INDEX]

This section provides the specific technical and strategic details that power the AI Boardroom.

### [A-1] The Weighted Response Equation (The Math)

**Overview:** This system is not a literal mathematical equation run in code, but rather a prompt-engineering strategy that instructs Maestro on how to prioritize information. It balances five core "ingredients" to ensure the most relevant response.

**The Five Core Context Layers (The "Ingredients"):** These are the five blocks of information Maestro considers for every decision.

1.  **User Objective (Weight: ~35%):**
    *   **What it is:** The user's most recent and direct instruction.
    *   **Why it's highest:** The system must be responsive and prioritize the user's immediate needs above all else.
2.  **Super Prompt (Weight: ~20%):**
    *   **What it is:** The "game plan" for the current mode (Boardroom, Project, etc.). This includes the overall goal, agent roles, and rules of engagement.
    *   **Why it's important:** It keeps the agents on-task and ensures the conversation adheres to the "physics" of the chosen mode.
3.  **Supporting Files (Contextual RAG) (Weight: ~15%):**
    *   **What it is:** The knowledge extracted from user-uploaded files (PDFs, DOCX, etc.).
    *   **Why it's important:** Ensures the conversation is "grounded" in the user's specific data.
4.  **Global Summary (L2 Memory) (Weight: ~15%):**
    *   **What it is:** The summarized history of the current session or relevant past sessions.
    *   **Why it's important:** Provides continuity and prevents the AI from "forgetting" what was discussed 20 messages ago.
5.  **Other Bots (L1 Memory) (Weight: ~15%):**
    *   **What it is:** The most recent statements made by other agents in the conversation.
    *   **Why it's important:** This is the "Shadow Listening" mechanism that allows for cross-agent collaboration, validation, and debate.

**The Three-Step Scoring Process (Conceptual Logic):** For any given task, Maestro conceptually "scores" its options based on three criteria:

1.  **Relevance Score (0-1):** How directly does this action address the User Objective?
2.  **Alignment Score (0-1):** How well does this action fit the Super Prompt and the agent's defined Role?
3.  **Contribution Score (0-1):** Does this action add new, valuable information (from RAG, L2 Memory, or critical thought) to the conversation?

**The Final "Decision":** Maestro is instructed to generate a response that maximizes all three scores, balanced by the prioritized weights of the five ingredients. This framework ensures the AI is responsive, on-topic, context-aware, and collaborative.

### [A-2] The 5-Phase, 18-Week Development Roadmap

This v1.0 product was built following a phased, 18-week roadmap.

*   **Phase 1: Foundations (Weeks 1-3)**
    *   Implement the secure API key proxy (serverless function).
    *   Implement local storage with AES-256 encryption.
    *   Develop the core cache system (`utils/cache.ts`).
    *   Define the data schemas for all four modes.
    *   Build the basic Tri-Cameral UI structure (Workshop, Chamber, Archive) with glassmorphism styling.
*   **Phase 2: Core Logic (Weeks 4-7)**
    *   Build the Maestro orchestration layer (the "Custom State Machine").
    *   Implement the Weighted Response prompt engineering.
    *   Build the Bot Archetype system (Brain, Persona, Skills).
    *   Implement session management (basic save/load).
    *   Build the core conversation flow for "Boardroom Mode."
*   **Phase 3: Interactivity & "Magic" (Weeks 8-11)**
    *   Implement real-time token streaming for responses.
    *   Build the "Shadow Listening" and "Interjection" logic.
    *   Implement the "Timeline" panel for decision tracking.
    *   Build out the "Social Sandbox" and "Project" mode logic.
    *   Implement TTS (Text-to-Speech) and STT (Speech-to-Text).
*   **Phase 4: Supporting Materials & Full Mode Parity (Weeks 12-15)**
    *   Build the client-side file processing pipeline (PDF, DOCX).
    *   Integrate the full 3-Layer RAG system (L1, L2, L3).
    *   Build the full "Archive" UI for managing checkpoints.
    *   Build out the "Comparison Mode" logic and UI.
    *   Implement report generation and data export.
*   **Phase 5: UX Refinements & Polish (Weeks 16-18)**
    *   Implement all mode-specific visual themes (e.g., "Validation Icons," "Executor Glows").
    *   Polish all animations and optimize performance.
    *   Ensure full PWA optimization for mobile/desktop.
    *   Build the "First-Time Use" onboarding flow.
    *   Final testing and deployment.

### [A-3] Custom State Machine Logic (Conceptual Overview)

**Why a Custom State Machine?**
Instead of integrating a heavy, complex library like LangGraph, we use a custom, lightweight state machine. This approach is:

*   **Lightweight:** Runs entirely in the client with minimal code.
*   **Flexible:** Easily adaptable to the unique logic of each of the four modes.
*   **Transparent:** The logic is clear and contained within our own simulation functions.

**Conceptual States & Transitions:**
Our conversation engine moves between several key "states."

*   **Core States:**
    *   `IDLE`: The system is waiting for user input.
    *   `USER_TURN`: The user has submitted a message; Maestro is processing it.
    *   `MAESTRO_PLANNING`: Maestro is analyzing the user's request and the current context to decide which agent speaks next or what task to execute.
    *   `AGENT_TURN`: Maestro has passed control to a specific agent, which is generating its response.
    *   `MAESTRO_SYNTHESIZING`: Maestro is summarizing the last few turns or compiling the final output from "Executor" agents.
*   **Mode-Specific States:**
    *   **Boardroom Mode** adds a `MAESTRO_VALIDATING` state. After an `AGENT_TURN`, Maestro pauses and instructs other agents to "vote" or "critique" the response, parsing their replies to assign a (✅❌⚠️) icon before proceeding.
    *   **Project Mode** adds an `EXECUTOR_WORKING` state, where multiple "Executor" agents run their tasks in parallel.

This state-based approach is what allows a user to "interject" at any time. A user message forces the machine from any state (e.g., `AGENT_TURN`) back to `USER_TURN`, ensuring the user always has priority.

### [B-1] Security Framework (AES-256 & Role-Based Responsibilities)

1.  **AES-256 Encryption (Data at Rest):**
    *   **What is Encrypted:** All "Checkpoint" session files saved to your browser's local storage via the "Archive" panel.
    *   **How it Works:** When you click "Save Session," the entire session state (JSON) is encrypted using a standard, vetted client-side JavaScript cryptographic library (`crypto-js`). It is stored in its encrypted form.
    *   **Why:** This protects your sensitive session data at rest on your local machine. Even if someone gained access to your computer, your archived conversations would be unreadable without the decryption key (which is managed by the app).
2.  **Role-Based Responsibilities (Not "ReBAC"):**
    This is a critical distinction. We do not implement a complex, multi-user technical framework like Role-Based Access Control (ReBAC), as that is irrelevant for a single-user, client-side application.

    Instead, we enforce "Role-Based Responsibilities" through prompt engineering and our Custom State Machine.

    *   **Maestro Role:** This role has "conductor" responsibilities. Its prompts and logic allow it to moderate debates, assign tasks, and manage the flow of the conversation.
    *   **Agent Role:** This role has "functional" responsibilities. Its prompts strictly limit it to its defined persona and skills. An "Analyst" agent cannot decide to moderate the debate, just as Maestro cannot decide to do the financial analysis itself.

    This framework ensures agents operate within their defined boundaries, providing a structured and reliable simulation.

### [B-2] The "Smart-Cache" & Caching Strategy

**Goal:** To significantly reduce API costs and improve response speed by avoiding redundant LLM calls.

**The "Smart-Cache" (Identical Request Cache):**
This is our primary caching strategy, implemented entirely on the client side.

*   **How it Works:** Before any API call is made, the system creates a unique "key."
*   **The Key:** A cryptographic hash (e.g., SHA-256) of the entire request: `hash(full_prompt_text + model_name + temperature + max_tokens)`.
*   **The Logic:**
    1.  System generates the key for the outgoing request.
    2.  It checks an in-memory `Map` (our cache) for this key.
    3.  **Cache Hit:** If the key exists, the cached response is returned instantly, and no API call is made.
    4.  **Cache Miss:** If the key does not exist, the API call proceeds. When the response is received, it is stored in the cache: `cache.set(key, response)`.
*   **Cache Invalidation:** This "Smart-Cache" is held in memory and is automatically cleared when you start a new session, load a checkpoint, or manually clear the cache, ensuring you can always get fresh responses when needed. This is most effective for "Executor" tasks or "Boardroom" validations that are highly deterministic.

### [C-1] Full Technical Stack (PWA / Browser-Native Stack)

This application is a Progressive Web App (PWA), built to run entirely in your browser with no complex server dependencies. This allows you to "install" it on your desktop or mobile device for an offline-capable, app-like experience.

*   **Core Framework:** React (v18+) with Vite for high-speed development and bundling.
*   **Styling:** Tailwind CSS for a utility-first, responsive design system.
*   **State Management:**
    *   React Context & Hooks: For managing global UI state (e.g., current mode, selected agent).
    *   Custom State Machine: Our internal logic (see [A-3]) for managing the conversation flow.
*   **Client-Side AI & RAG:**
    *   `transformers.js`: Used to generate text embeddings in the browser (via WASM) for RAG.
    *   `voy-search`: A lightweight, client-side (WASM) vector search library to power our RAG.
*   **Client-Side File Parsing:**
    *   `pdf.js`: Used to extract text content from uploaded `.pdf` files.
    *   `mammoth.js`: Used to extract text content from uploaded `.docx` files.
*   **Security:**
    *   `crypto-js` (or similar): Used for AES-256 encryption of all session data saved to local storage.
*   **Backend & Deployment:**
    *   **Deployment:** Deployed as a static site on any modern hosting platform (e.g., Vercel, Netlify, Firebase Hosting).
    *   **Backend:** A single, lightweight Serverless Function (e.g., a Vercel Function) acts as a Secure API Key Proxy. This is the only "backend" component, and its sole purpose is to protect your API keys. It does not see or store any of your personal data.
