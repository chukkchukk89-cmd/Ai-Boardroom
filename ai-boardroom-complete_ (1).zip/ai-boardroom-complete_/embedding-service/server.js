const express = require('express');
const cors = require('cors');
const { TextEmbedder, FilesetResolver } = require('@mediapipe/tasks-text');

const app = express();
const port = process.env.PORT || 3000;

app.use(cors());
app.use(express.json({ limit: '5mb' })); // Allow larger text bodies

let textEmbedder;

// A function to initialize the TextEmbedder
const initializeTextEmbedder = async () => {
  try {
    const textResolver = await FilesetResolver.forTextTasks(
      'https://cdn.jsdelivr.net/npm/@mediapipe/tasks-text@0.10.14/wasm'
    );
    textEmbedder = await TextEmbedder.createFromOptions(textResolver, {
      baseOptions: {
        modelAssetPath: 'https://storage.googleapis.com/mediapipe-models/text_embedder/universal_sentence_encoder/float32/1/universal_sentence_encoder.tflite',
      },
      quantize: false,
    });
    console.log('✅ Text Embedder initialized successfully.');
  } catch (error) {
    console.error('Failed to initialize Text Embedder:', error);
    // Exit the process if the model can't be loaded, as the service is useless without it.
    process.exit(1);
  }
};

// Endpoint to handle text embedding
app.post('/embed', async (req, res) => {
  if (!textEmbedder) {
    return res.status(503).json({ error: 'Text Embedder is not initialized yet. Please try again in a moment.' });
  }
  
  const { text } = req.body;
  if (!text || typeof text !== 'string') {
    return res.status(400).json({ error: 'Request body must contain a "text" field with a string value.' });
  }

  try {
    const startTime = Date.now();
    const embeddings = textEmbedder.embed(text);
    const duration = Date.now() - startTime;
    
    console.log(`Embedded text in ${duration}ms.`);
    
    // The result from MediaPipe contains multiple embeddings if the text is long.
    // For simplicity, we'll take the first one, which represents the whole text.
    // A more advanced implementation could average them.
    const vector = embeddings.embeddings[0]?.embedding;

    if (!vector) {
        throw new Error('Failed to generate embedding from the provided text.');
    }

    res.json({ vector });

  } catch (error) {
    console.error('Embedding Error:', error);
    res.status(500).json({ error: 'Failed to generate text embedding.' });
  }
});

// Health check endpoint
app.get('/', (req, res) => {
  res.send('Embedding service is running.');
});

// Initialize the embedder and then start the server
initializeTextEmbedder().then(() => {
  app.listen(port, () => {
    console.log(`Embedding service listening on port ${port}`);
  });
});
