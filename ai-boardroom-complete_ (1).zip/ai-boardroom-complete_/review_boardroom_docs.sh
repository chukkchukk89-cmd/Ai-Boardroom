#!/bin/bash

echo "Please review the Boardroom_Docs for the ai-boardroom-complete_ project, including compendium.md, implementation_plan.md, and progress_report.md."
echo "Reminder: Update progress_report.md after every implementation."
