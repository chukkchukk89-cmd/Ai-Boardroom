import React, { useState } from 'react';

interface ProviderInfo {
  name: string;
  url: string;
  docsNote?: string;
}

const PROVIDER_INFO: { [key: string]: ProviderInfo } = {
  Gemini: {
    name: "Gemini",
    url: "https://aistudio.google.com/app/apikey",
  },
  Anthropic: {
    name: "Anthropic (Claude)",
    url: "https://console.anthropic.com/dashboard",
  },
  Groq: {
    name: "Groq (Llama)",
    url: "https://console.groq.com/keys",
  },
  DeepSeek: {
    name: "DeepSeek",
    url: "https://platform.deepseek.com/",
  },
  Qwen: {
    name: "Alibaba Cloud (Qwen)",
    url: "https://www.aliyun.com/product/bailian",
  }
};


interface ApiKeyModalProps {
  provider: string | null;
  onClose: () => void;
  onSave: (provider: string, apiKey: string) => void;
}

export const ApiKeyModal: React.FC<ApiKeyModalProps> = ({ provider, onClose, onSave }) => {
  const [apiKey, setApiKey] = useState('');

  if (!provider) return null;

  const info = PROVIDER_INFO[provider];

  if (!info) {
      console.error(`API Key modal opened for unknown provider: ${provider}`);
      return null;
  }

  const handleSave = () => {
    if (apiKey.trim()) {
      onSave(provider, apiKey.trim());
      onClose();
    }
  };

  return (
    <div 
      className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center"
      onClick={onClose}
      aria-modal="true"
      role="dialog"
    >
      <div 
        className="bg-gray-800 border border-gray-700 rounded-2xl shadow-xl w-full max-w-md p-6 m-4"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-bold text-white">Set {info.name} API Key</h2>
          <button onClick={onClose} className="text-gray-400 hover:text-white">&times;</button>
        </div>
        <div className="text-gray-300 space-y-4">
          <p>To use {info.name} models, you must provide your own API key. The key will be saved securely in your browser's local storage and will not be shared.</p>
          
          <div className="space-y-2">
            <p className="font-semibold">Step 1: Get your key</p>
            <p>
              Visit the {info.name} developer console to create and copy your API key.
            </p>
            <a 
              href={info.url} 
              target="_blank" 
              rel="noopener noreferrer"
              className="inline-block w-full text-center bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-4 rounded-lg transition-colors"
            >
              Get API Key from {info.name}
            </a>
          </div>

          <div className="space-y-2">
            <p className="font-semibold">Step 2: Enter your key</p>
            <input
                type="password"
                value={apiKey}
                onChange={(e) => setApiKey(e.target.value)}
                placeholder={`Paste your ${info.name} API key here`}
                className="w-full bg-gray-900 border border-gray-600 rounded-lg p-3 text-gray-200 focus:ring-2 focus:ring-purple-500 focus:outline-none"
            />
          </div>
          
        </div>
        <div className="mt-6 flex justify-end gap-4">
          <button 
            onClick={onClose} 
            className="px-6 py-2 bg-gray-600 rounded-md hover:bg-gray-700 transition-colors text-sm font-semibold"
          >
            Cancel
          </button>
          <button 
            onClick={handleSave}
            disabled={!apiKey.trim()}
            className="px-6 py-2 bg-purple-600 rounded-md hover:bg-purple-700 transition-colors text-sm font-semibold disabled:bg-gray-500 disabled:cursor-not-allowed"
          >
            Save Key
          </button>
        </div>
      </div>
    </div>
  );
};