import React from 'react';
import { ModeTabs } from './components/ModeTabs';
import { AgentCreationPanel } from './components/AgentCreationPanel';
import { SessionLoggingPanel } from './components/SessionLoggingPanel';
import { UserInputBar } from './components/UserInputBar';
import { ConversationalGraphView } from './components/ConversationalGraphView';
import { ApiKeyModal } from './components/ApiKeyModal';
import { AudioPlaybackBar } from './components/AudioPlaybackBar';
import { Timeline } from './components/Timeline';
import { SessionManagementPanel } from './components/SessionManagementPanel';
import { ModeInfoOverlay } from './components/ModeInfoOverlay';
import { MaestroAdvisoryPanel } from './components/MaestroAdvisoryPanel';
import { Boardroom } from './components/Boardroom';
import { ProjectMode } from './components/ProjectMode';
import { SocialSandbox } from './components/SocialSandbox';
import { ComparisonMode } from './components/ComparisonMode';
import { SessionFilesPanel } from './components/SessionFilesPanel';
import { useAppContext } from './contexts/AppContext';

export const MainApp: React.FC = () => {
  const {
    activeMode, setActiveMode, showModeInfo, setShowModeInfo,
    agentConfigs, setAgentConfigs, agents, setAgents,
    isSessionActive, setIsSessionActive, sessionLog, setSessionLog,
    timelineEvents, setTimelineEvents, activeAgentId, setActiveAgentId,
    prevActiveAgentId, setPrevActiveAgentId, sessionGoal, setSessionGoal,
    finalDocument, setFinalDocument, uploadedFiles, setUploadedFiles,
    sessionControlRef,
    advisoryGoal, setAdvisoryGoal, isConsultingMaestro, setIsConsultingMaestro,
    itinerary, setItinerary, isItinerarySet, setIsItinerarySet,
    projectData, setProjectData, sandboxScenario, setSandboxScenario,
    isSandboxSetup, setIsSandboxSetup, analysisSuggestions, setAnalysisSuggestions,
    isSuggestingAnalysis, setIsSuggestingAnalysis,
    temperature, setTemperature, conversationTemperature, setConversationTemperature,
    outputFormat, setOutputFormat, apiKeyModalProvider, setApiKeyModalProvider,
    audioContextRef, activeAudioEntryId, setActiveAudioEntryId,
    currentlySpeakingAgent, setCurrentlySpeakingAgent, audioQueueRef, isPlayingRef,
    addLogEntry, handleStopAudio, handleStartSession, handleStopSession,
    handleUserMessage, handleModeChange, handleModeInfoClose, handleConsultMaestro,
    handleGenerateItinerary, handleSetupSandbox, handleSuggestAnalysis,
    handleGenerateAnalysis, handleFileUpload, handleRemoveFile, scrollToLogEntry, handleSaveApiKey,
  } = useAppContext();

  const showAdvisory = !sessionGoal && !projectData && !sandboxScenario;

  return (
    <div className="bg-gray-900 text-white font-sans h-screen flex flex-col p-4 gap-4">
      {showModeInfo && <ModeInfoOverlay mode={showModeInfo} onClose={handleModeInfoClose} />}
      <ApiKeyModal provider={apiKeyModalProvider} onClose={() => setApiKeyModalProvider(null)} onSave={handleSaveApiKey} />
      <AudioPlaybackBar speaker={currentlySpeakingAgent} isPlaying={!!activeAudioEntryId} onTogglePlay={handleStopAudio} />

      <header className="flex-shrink-0">
        <ModeTabs activeMode={activeMode} onModeChange={handleModeChange} disabled={isSessionActive} />
      </header>

      <main className="flex-grow grid grid-cols-12 grid-rows-6 gap-4 min-h-0">
        <section className="col-span-3 row-span-4">
          <AgentCreationPanel 
            setAgents={setAgents}
            agentConfigs={agentConfigs}
            setAgentConfigs={setAgentConfigs}
            isSessionActive={isSessionActive}
            onApiKeyClick={setApiKeyModalProvider}
          />
        </section>
        
        <section className="col-span-6 row-span-4 min-h-0">
          {showAdvisory && <MaestroAdvisoryPanel advisoryGoal={advisoryGoal} setAdvisoryGoal={setAdvisoryGoal} onConsult={handleConsultMaestro} isLoading={isConsultingMaestro}/>}
          {!showAdvisory && activeMode === 'Boardroom' && <Boardroom 
            projectGoal={sessionGoal}
            setProjectGoal={setSessionGoal}
            itinerary={itinerary}
            setItinerary={setItinerary}
            isItinerarySet={isItinerarySet}
            finalDocument={finalDocument}
            isSessionActive={isSessionActive}
            onGenerateItinerary={handleGenerateItinerary}
            onAnalyzeHealth={() => {}}
            agents={agents}
          />}
          {!showAdvisory && activeMode === 'Project' && <ProjectMode projectData={projectData} agents={agents} finalDocument={finalDocument} />}
          {!showAdvisory && activeMode === 'SocialSandbox' && <SocialSandbox 
            scenario={sandboxScenario}
            setScenario={setSandboxScenario}
            onSetup={handleSetupSandbox}
            isSetup={isSandboxSetup}
            isSessionActive={isSessionActive}
            agents={agents}
            agentConfigs={agentConfigs}
            onSuggestAnalysis={handleSuggestAnalysis}
            onGenerateAnalysis={handleGenerateAnalysis}
            analysisSuggestions={analysisSuggestions}
            isSuggestingAnalysis={isSuggestingAnalysis}
            finalDocument={finalDocument}
          />}
          {activeMode === 'Comparison' && <ComparisonMode />}
        </section>

        <section className="col-span-3 row-span-6 relative">
          <SessionLoggingPanel log={sessionLog} onAudioPlayback={() => {}} activeAudioEntryId={activeAudioEntryId} containerId="session-log-container" />
          <Timeline events={timelineEvents} onEventClick={scrollToLogEntry} containerId="session-log-container" />
        </section>

        <section className="col-span-3 row-span-2">
          <SessionManagementPanel 
            isSessionActive={isSessionActive}
            onStart={handleStartSession}
            onStop={handleStopSession}
            temperature={temperature}
            setTemperature={setTemperature}
            conversationTemperature={conversationTemperature}
            setConversationTemperature={setConversationTemperature}
            outputFormat={outputFormat}
            setOutputFormat={setOutputFormat}
            activeMode={activeMode}
            isReady={!!sessionGoal || !!projectData || !!sandboxScenario}
          />
        </section>

        <section className="col-span-6 row-span-2 min-h-0">
          <div className="h-full flex flex-col gap-4">
            <div className="flex-grow min-h-0">
              <ConversationalGraphView agents={agents} activeAgentId={activeAgentId} prevActiveAgentId={prevActiveAgentId} isLowPowerMode={false} />
            </div>
            <div className="flex-shrink-0">
              <UserInputBar onSendMessage={handleUserMessage} isSessionActive={isSessionActive} />
            </div>
          </div>
        </section>
        
        {/* Re-locating SessionFilesPanel for a better layout, if we decide to use it */}
        {/* <section className="col-span-3 row-span-2">
          <SessionFilesPanel files={uploadedFiles} onFileUpload={handleFileUpload} onRemoveFile={handleRemoveFile} isSessionActive={isSessionActive} />
        </section> */}

      </main>
    </div>
  );
};
