import React, { createContext, useState, useContext, useRef, useEffect, useCallback } from 'react';
import { v4 as uuidv4 } from 'uuid';
import { Agent, AgentConfig, AppMode, SessionLogEntry, TimelineEvent, ItineraryItem, ProjectData, UploadedFile, MaestroPromptContext, ConversationTemperature, OutputFormat } from '../types';
import { generateAgentResponse } from '../maestro/maestroPrompting';
import { runProjectSimulation } from '../maestro/runProjectSimulation';
import { MAESTRO_BOARDROOM_PROMPTS, MAESTRO_PLANNING_PROMPTS, MAESTRO_SANDBOX_PROMPTS } from '../prompts';
import { decodeAudioData } from '../utils/audio';
import { getFromCache, setInCache } from '../utils/cache';
import { defaultProject } from '../data/defaultProject';
import { GoogleGenAI, Modality } from '@google/genai';

interface AppContextType {
  // Global App State
  activeMode: AppMode;
  setActiveMode: React.Dispatch<React.SetStateAction<AppMode>>;
  showModeInfo: AppMode | null;
  setShowModeInfo: React.Dispatch<React.SetStateAction<AppMode | null>>;

  // Agent & Session State
  agentConfigs: AgentConfig[];
  setAgentConfigs: React.Dispatch<React.SetStateAction<AgentConfig[]>>;
  agents: Agent[];
  setAgents: React.Dispatch<React.SetStateAction<Agent[]>>;
  isSessionActive: boolean;
  setIsSessionActive: React.Dispatch<React.SetStateAction<boolean>>;
  sessionLog: SessionLogEntry[];
  setSessionLog: React.Dispatch<React.SetStateAction<SessionLogEntry[]>>;
  timelineEvents: TimelineEvent[];
  setTimelineEvents: React.Dispatch<React.SetStateAction<TimelineEvent[]>>;
  activeAgentId: string | null;
  setActiveAgentId: React.Dispatch<React.SetStateAction<string | null>>;
  prevActiveAgentId: string | null;
  setPrevActiveAgentId: React.Dispatch<React.SetStateAction<string | null>>;
  sessionGoal: string;
  setSessionGoal: React.Dispatch<React.SetStateAction<string>>;
  finalDocument: string | null;
  setFinalDocument: React.Dispatch<React.SetStateAction<string | null>>;
  uploadedFiles: UploadedFile[];
  setUploadedFiles: React.Dispatch<React.SetStateAction<UploadedFile[]>>;
  sessionControlRef: React.MutableRefObject<{ isRunning: boolean }>;

  // Mode-Specific State
  advisoryGoal: string;
  setAdvisoryGoal: React.Dispatch<React.SetStateAction<string>>;
  isConsultingMaestro: boolean;
  setIsConsultingMaestro: React.Dispatch<React.SetStateAction<boolean>>;
  itinerary: ItineraryItem[];
  setItinerary: React.Dispatch<React.SetStateAction<ItineraryItem[]>>;
  isItinerarySet: boolean;
  setIsItinerarySet: React.Dispatch<React.SetStateAction<boolean>>;
  projectData: ProjectData | null;
  setProjectData: React.Dispatch<React.SetStateAction<ProjectData | null>>;
  sandboxScenario: string;
  setSandboxScenario: React.Dispatch<React.SetStateAction<string>>;
  isSandboxSetup: boolean;
  setIsSandboxSetup: React.Dispatch<React.SetStateAction<boolean>>;
  analysisSuggestions: {title: string, prompt: string}[];
  setAnalysisSuggestions: React.Dispatch<React.SetStateAction<{title: string, prompt: string}[]>>;
  isSuggestingAnalysis: boolean;
  setIsSuggestingAnalysis: React.Dispatch<React.SetStateAction<boolean>>;

  // Config State
  temperature: number;
  setTemperature: React.Dispatch<React.SetStateAction<number>>;
  conversationTemperature: ConversationTemperature;
  setConversationTemperature: React.Dispatch<React.SetStateAction<ConversationTemperature>>;
  outputFormat: OutputFormat;
  setOutputFormat: React.Dispatch<React.SetStateAction<OutputFormat>>;
  apiKeyModalProvider: string | null;
  setApiKeyModalProvider: React.Dispatch<React.SetStateAction<string | null>>;
  apiKeys: { [provider: string]: string };

  // Audio State
  audioContextRef: React.MutableRefObject<AudioContext | null>;
  activeAudioEntryId: string | null;
  setActiveAudioEntryId: React.Dispatch<React.SetStateAction<string | null>>;
  currentlySpeakingAgent: { role: string; avatar: string; } | null;
  setCurrentlySpeakingAgent: React.Dispatch<React.SetStateAction<{ role: string; avatar: string; } | null>>;
  audioQueueRef: React.MutableRefObject<{ audio: string; entryId: string; }[]>;
  isPlayingRef: React.MutableRefObject<boolean>;

  // Functions
  addLogEntry: (role: string, avatar: string, content: string, audio?: string) => void;
  handleStopAudio: () => void;
  handleStartSession: () => void;
  handleStopSession: () => void;
  handleUserMessage: (message: string) => void;
  handleModeChange: (mode: AppMode) => void;
  handleModeInfoClose: (dontShowAgain: boolean) => void;
  handleSaveApiKey: (provider: string, apiKey: string) => void;
  handleConsultMaestro: () => Promise<void>;
  handleGenerateItinerary: () => Promise<void>;
  handleSetupSandbox: () => Promise<void>;
  handleSuggestAnalysis: () => Promise<void>;
  handleGenerateAnalysis: (prompt: string) => Promise<void>;
  handleFileUpload: (newFiles: UploadedFile[]) => void;
  handleRemoveFile: (fileId: string) => void;
  scrollToLogEntry: (refId: string) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Global App State
  const [activeMode, setActiveMode] = useState<AppMode>('Boardroom');
  const [showModeInfo, setShowModeInfo] = useState<AppMode | null>(null);

  // Agent & Session State
  const [agentConfigs, setAgentConfigs] = useState<AgentConfig[]>([]);
  const [agents, setAgents] = useState<Agent[]>([]);
  const [isSessionActive, setIsSessionActive] = useState(false);
  const [sessionLog, setSessionLog] = useState<SessionLogEntry[]>([]);
  const [timelineEvents, setTimelineEvents] = useState<TimelineEvent[]>([]);
  const [activeAgentId, setActiveAgentId] = useState<string | null>(null);
  const [prevActiveAgentId, setPrevActiveAgentId] = useState<string | null>(null);
  const [sessionGoal, setSessionGoal] = useState('');
  const [finalDocument, setFinalDocument] = useState<string | null>(null);
  const [uploadedFiles, setUploadedFiles] = useState<UploadedFile[]>([]);
  const sessionControlRef = useRef({ isRunning: false });

  // Mode-Specific State
  const [advisoryGoal, setAdvisoryGoal] = useState('');
  const [isConsultingMaestro, setIsConsultingMaestro] = useState(false);
  const [itinerary, setItinerary] = useState<ItineraryItem[]>([]);
  const [isItinerarySet, setIsItinerarySet] = useState(false);
  const [projectData, setProjectData] = useState<ProjectData | null>(null);
  const [sandboxScenario, setSandboxScenario] = useState('');
  const [isSandboxSetup, setIsSandboxSetup] = useState(false);
  const [analysisSuggestions, setAnalysisSuggestions] = useState<{title: string, prompt: string}[]>([]);
  const [isSuggestingAnalysis, setIsSuggestingAnalysis] = useState(false);

  // Config State
  const [temperature, setTemperature] = useState(0.7);
  const [conversationTemperature, setConversationTemperature] = useState<ConversationTemperature>('Orderly');
  const [outputFormat, setOutputFormat] = useState<OutputFormat>('Markdown');
  const [apiKeyModalProvider, setApiKeyModalProvider] = useState<string | null>(null);
  const [apiKeys, setApiKeys] = useState<{ [key: string]: string }>({});

  // Audio State
  const audioContextRef = useRef<AudioContext | null>(null);
  const [activeAudioEntryId, setActiveAudioEntryId] = useState<string | null>(null);
  const [currentlySpeakingAgent, setCurrentlySpeakingAgent] = useState<{ role: string; avatar: string; } | null>(null);
  const audioQueueRef = useRef<{ audio: string; entryId: string; }[]>([]);
  const isPlayingRef = useRef(false);

  // Effect for one-time initialization
  useEffect(() => {
    const dismissedModes = getFromCache<AppMode[]>('dismissed_mode_info') || [];
    if (!dismissedModes.includes(activeMode)) {
      setShowModeInfo(activeMode);
    }
    const savedKeys = getFromCache<{ [key: string]: string }>('api_keys');
    if (savedKeys) {
      setApiKeys(savedKeys);
    }
    document.addEventListener('click', initAudio, { once: true });
    return () => document.removeEventListener('click', initAudio);
  }, []);

  const handleSaveApiKey = (provider: string, apiKey: string) => {
    const newKeys = { ...apiKeys, [provider]: apiKey };
    setApiKeys(newKeys);
    setInCache('api_keys', newKeys);
  };

  const getApiKey = (provider: string): string | undefined => {
    return apiKeys[provider];
  };

  const initAudio = () => {
    if (!audioContextRef.current) {
      audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
    }
  }
  
  // Core Logging Function
  const addLogEntry = (role: string, avatar: string, content: string, audio?: string) => {
    const id = uuidv4();
    const newEntry: SessionLogEntry = { id, timestamp: Date.now(), role, avatar, content, audio };
    setSessionLog(prev => [...prev, newEntry]);
    
    const agent = agents.find(a => a.role === role);
    const type = role === 'User' ? 'user_input' : agent?.role === 'Maestro' ? 'decision' : 'agent_contribution';
    
    const newEvent: TimelineEvent = {
      id: uuidv4(),
      timestamp: newEntry.timestamp,
      type,
      title: role,
      description: content.substring(0, 50) + '...',
      refId: id,
    };
    setTimelineEvents(prev => [...prev, newEvent]);

    if (audio && agent?.voice) {
      audioQueueRef.current.push({ audio, entryId: id });
      processAudioQueue();
    }
  };

  // Audio Playback Logic
  const processAudioQueue = async () => {
    if (isPlayingRef.current || audioQueueRef.current.length === 0) return;
    
    isPlayingRef.current = true;
    const { audio, entryId } = audioQueueRef.current.shift()!;
    
    try {
      if (!audioContextRef.current) initAudio();
      if (!audioContextRef.current) throw new Error("Audio context not available");
      
      const agent = agents.find(a => sessionLog.find(l => l.id === entryId)?.role === a.role);
      if(agent) setCurrentlySpeakingAgent({ role: agent.role, avatar: agent.avatar });
      setActiveAudioEntryId(entryId);

      const decodedBuffer = await decodeAudioData(
        new Uint8Array(atob(audio).split('').map(c => c.charCodeAt(0))),
        audioContextRef.current,
        24000, 1
      );
      const source = audioContextRef.current.createBufferSource();
      source.buffer = decodedBuffer;
      source.connect(audioContextRef.current.destination);
      source.start();
      source.onended = () => {
        setActiveAudioEntryId(null);
        setCurrentlySpeakingAgent(null);
        isPlayingRef.current = false;
        processAudioQueue();
      };
    } catch (error) {
      console.error("Error playing audio:", error);
      isPlayingRef.current = false;
      setActiveAudioEntryId(null);
      setCurrentlySpeakingAgent(null);
    }
  };

  const handleStopAudio = () => {
    audioQueueRef.current = [];
    isPlayingRef.current = false;
    setActiveAudioEntryId(null);
    setCurrentlySpeakingAgent(null);
    console.log("Audio playback stopped.");
  };
  
  // Simulation Control
  const handleStartSession = () => {
    if (agents.length <= 1) {
      alert("Please configure at least one agent besides the Maestro.");
      return;
    }
    
    setFinalDocument(null);
    setSessionLog([]);
    setTimelineEvents([]);
    setIsSessionActive(true);
    sessionControlRef.current.isRunning = true;
    
    addLogEntry('Maestro', '👑', `Session started in ${activeMode} mode. Goal: ${sessionGoal || projectData?.goal || sandboxScenario}`, undefined);

    if (activeMode === 'Boardroom') {
      runBoardroomSimulation();
    } else if (activeMode === 'Project' && projectData) {
      runProjectSimulation(projectData, agents, (update) => {
        if(update.log) addLogEntry(update.log.role, update.log.avatar, update.log.content);
        if(update.agentStatus) setAgents(prev => prev.map(a => a.id === update.agentStatus!.agentId ? { ...a, status: update.agentStatus!.status, currentTask: update.agentStatus!.task } : a));
        if(update.milestoneStatus) setProjectData(prev => prev ? ({ ...prev, milestones: prev.milestones.map(m => m.milestoneId === update.milestoneStatus!.milestoneId ? { ...m, currentStatus: update.milestoneStatus!.status } : m) }) : null);
        if(update.finalDocument) setFinalDocument(update.finalDocument);

      }, sessionControlRef, getApiKey);
    } else if (activeMode === 'SocialSandbox') {
      runSocialSandboxSimulation();
    }
  };

  const handleStopSession = () => {
    setIsSessionActive(false);
    sessionControlRef.current.isRunning = false;
    setActiveAgentId(null);
    setAgents(prev => prev.map(a => ({ ...a, status: 'idle', currentTask: null })));
    addLogEntry('Maestro', '👑', 'Session stopped by user.', undefined);
  };

  // Main Simulation Loop for Boardroom
  const runBoardroomSimulation = async () => {
    const participants = agents.filter(a => a.role !== 'Maestro');
    let lastSpeakerIndex = -1;

    for (const item of itinerary) {
      if (!sessionControlRef.current.isRunning) break;
      
      addLogEntry('Maestro', '👑', `New agenda item: "${item.text}"`, undefined);

      for (let i = 0; i < participants.length; i++) {
        if (!sessionControlRef.current.isRunning) break;
        
        lastSpeakerIndex = (lastSpeakerIndex + 1) % participants.length;
        const currentAgent = participants[lastSpeakerIndex];

        const apiKey = getApiKey(currentAgent.model.provider);
        if (!apiKey) {
            setApiKeyModalProvider(currentAgent.model.provider);
            handleStopSession();
            return;
        }

        setAgents(prev => prev.map(a => a.id === currentAgent.id ? { ...a, status: 'working', currentTask: item.text } : a));
        setPrevActiveAgentId(activeAgentId);
        setActiveAgentId(currentAgent.id);

        const context: MaestroPromptContext = {
          mode: 'Boardroom',
          agent: currentAgent, agents, userName: 'User', sessionGoal,
          lastTurns: sessionLog.slice(-5),
          currentItineraryItem: item,
        };
        
        const response = await generateAgentResponse(context, "Please provide your input on the current topic.", temperature, apiKey);
        
        addLogEntry(currentAgent.role, currentAgent.avatar, response.text, response.audio);
        setAgents(prev => prev.map(a => a.id === currentAgent.id ? { ...a, status: 'done' } : a));
      }
    }
    
    // Final Synthesis
    if (sessionControlRef.current.isRunning) {
      const maestro = agents.find(a => a.role === 'Maestro')!;
      const apiKey = getApiKey(maestro.model.provider);
      if (!apiKey) {
        setApiKeyModalProvider(maestro.model.provider);
        handleStopSession();
        return;
      }

      setAgents(prev => prev.map(a => a.id === maestro.id ? { ...a, status: 'working', currentTask: "Synthesizing Master Plan" } : a));
      const fullTranscript = sessionLog.map(l => `${l.role}: ${l.content}`).join('\n');
      
      const ai = new GoogleGenAI(apiKey);
      const promptConfig = MAESTRO_BOARDROOM_PROMPTS.FINAL_SYNTHESIS(outputFormat);
      
      const result = await ai.getGenerativeModel({ model: maestro.model.modelName, systemInstruction: promptConfig.systemInstruction }).generateContent(`Synthesize the following meeting transcript:\n\n${fullTranscript}`);

      const doc = result.response.text();
      setFinalDocument(doc);
      addLogEntry('Maestro', '👑', 'Final document has been generated.', undefined);
    }

    handleStopSession();
  };

    // Main Simulation Loop for Social Sandbox
  const runSocialSandboxSimulation = async () => {
    const participants = agents.filter(a => a.role !== 'Maestro');
    const maestro = agents.find(a => a.role === 'Maestro')!;
    let nextSpeakerRole = participants[0].role; // Start with the first agent

    for (let i = 0; i < 10; i++) { // Limit to 10 turns for now
      if (!sessionControlRef.current.isRunning) break;

      const currentAgent = agents.find(a => a.role === nextSpeakerRole)!;
      const apiKey = getApiKey(currentAgent.model.provider);
      if (!apiKey) {
        setApiKeyModalProvider(currentAgent.model.provider);
        handleStopSession();
        return;
      }
      
      setAgents(prev => prev.map(a => a.id === currentAgent.id ? { ...a, status: 'working', currentTask: `Responding as ${currentAgent.role}` } : a));
      setPrevActiveAgentId(activeAgentId);
      setActiveAgentId(currentAgent.id);
      
      const context: MaestroPromptContext = {
        mode: 'SocialSandbox',
        agent: currentAgent, agents, userName: 'User', sessionGoal: sandboxScenario,
        lastTurns: sessionLog.slice(-5),
        sandboxScenario,
      };

      const response = await generateAgentResponse(context, "Continue the conversation.", temperature, apiKey);
      addLogEntry(currentAgent.role, currentAgent.avatar, response.text, response.audio);
      setAgents(prev => prev.map(a => a.id === currentAgent.id ? { ...a, status: 'done' } : a));

      // Maestro decides who is next
      const maestroApiKey = getApiKey(maestro.model.provider);
      if (!maestroApiKey) {
        setApiKeyModalProvider(maestro.model.provider);
        handleStopSession();
        return;
      }
      const ai = new GoogleGenAI(maestroApiKey);
      const participantRoles = participants.map(p => p.role);
      const promptConfig = MAESTRO_SANDBOX_PROMPTS.DIRECT_NEXT_SPEAKER;
      const result = await ai.getGenerativeModel({ model: maestro.model.modelName, systemInstruction: promptConfig.systemInstruction(participantRoles) }).generateContent(`Given the last turn, who should speak next? Participants: ${participantRoles.join(', ')}

Transcript:
${sessionLog.map(l=>`${l.role}: ${l.content}`).slice(-3).join('
')}`);
      const { nextSpeaker } = JSON.parse(result.response.text());
      nextSpeakerRole = nextSpeaker;
    }
    
    handleStopSession();
  };


  const handleUserMessage = (message: string) => {
    addLogEntry('User', '👤', message, undefined);
  };
  
  // UI Handlers
  const handleModeChange = (mode: AppMode) => {
    if (isSessionActive) return;
    setActiveMode(mode);
    setSessionGoal('');
    setProjectData(null);
    setItinerary([]);
    setIsItinerarySet(false);
    const dismissedModes = getFromCache<AppMode[]>('dismissed_mode_info') || [];
    if (!dismissedModes.includes(mode)) {
      setShowModeInfo(mode);
    }
  };
  
  const handleModeInfoClose = (dontShowAgain: boolean) => {
    if (dontShowAgain) {
      const dismissed = getFromCache<AppMode[]>('dismissed_mode_info') || [];
      setInCache('dismissed_mode_info', [...dismissed, showModeInfo!]);
    }
    setShowModeInfo(null);
  };

  const handleConsultMaestro = async () => {
    const maestro = agents.find(a => a.role === 'Maestro') || agentConfigs.find(c => c.role === 'Maestro');
    if (!maestro) {
      alert("Maestro agent not found!");
      return;
    }
    const apiKey = getApiKey(maestro.model.provider);
    if (!apiKey) {
        setApiKeyModalProvider(maestro.model.provider);
        return;
    }

    setIsConsultingMaestro(true);
    try {
      const ai = new GoogleGenAI(apiKey);
      const promptConfig = MAESTRO_PLANNING_PROMPTS.INITIAL_USER_PROMPT_ANALYSIS;
      const result = await ai.getGenerativeModel({ model: maestro.model.modelName, systemInstruction: promptConfig.systemInstruction }).generateContent(advisoryGoal);
      
      const { recommendedMode, refinedGoal } = JSON.parse(result.response.text());
      
      setActiveMode(recommendedMode);
      if(recommendedMode === 'Boardroom') setSessionGoal(refinedGoal);
      if(recommendedMode === 'Project') { setProjectData(defaultProject); setSessionGoal(refinedGoal); }
      if(recommendedMode === 'SocialSandbox') setSandboxScenario(refinedGoal);

    } catch (error) {
      console.error("Error consulting Maestro:", error);
      alert("Maestro had trouble with that request. Please try rephrasing.");
    } finally {
        setIsConsultingMaestro(false);
    }
  };

  const handleGenerateItinerary = async () => {
    const maestro = agents.find(a => a.role === 'Maestro');
    if (!maestro) {
      alert("Maestro agent not found!");
      return;
    }
    const apiKey = getApiKey(maestro.model.provider);
    if (!apiKey) {
        setApiKeyModalProvider(maestro.model.provider);
        return;
    }
    try {
      const ai = new GoogleGenAI(apiKey);
      const promptConfig = MAESTRO_BOARDROOM_PROMPTS.ITINERARY_GENERATION;
      const result = await ai.getGenerativeModel({ model: maestro.model.modelName, systemInstruction: promptConfig.systemInstruction }).generateContent(sessionGoal);
      
      const { itinerary: generated } = JSON.parse(result.response.text());
      setItinerary(generated.map((text: string) => ({ id: uuidv4(), text, completed: false })));
      setIsItinerarySet(true);

    } catch (error) {
      console.error("Error generating itinerary:", error);
    }
  };
  
  const handleSetupSandbox = async () => {
    const maestro = agents.find(a => a.role === 'Maestro');
    if (!maestro) {
      alert("Maestro agent not found!");
      return;
    }
    const apiKey = getApiKey(maestro.model.provider);
    if (!apiKey) {
        setApiKeyModalProvider(maestro.model.provider);
        return;
    }
    const participants = agents.filter(a => a.role !== 'Maestro');
    if (participants.length === 0) {
      alert("At least one other agent must be configured.");
      return;
    }
    try {
      const ai = new GoogleGenAI(apiKey);
      const promptConfig = MAESTRO_SANDBOX_PROMPTS.SETUP_SCENARIO;
      const agentList = participants.map(p => ({ id: p.id, role: p.role, expertise: p.expertise }));
      const prompt = `Scenario: "${sandboxScenario}"

Available Agents:
${JSON.stringify(agentList, null, 2)}`;

      const result = await ai.getGenerativeModel({ model: maestro.model.modelName, systemInstruction: promptConfig.systemInstruction }).generateContent(prompt);

      const { agentPersonas } = JSON.parse(result.response.text());
      
      setAgents(prev => prev.map(agent => {
        const persona = agentPersonas.find((p: any) => p.agentId === agent.id);
        return persona ? { ...agent, role: persona.newRole, expertise: persona.personaDescription } : agent;
      }));
      
      setIsSandboxSetup(true);

    } catch (error) {
      console.error("Error setting up sandbox:", error);
    }
  };
  
  const handleSuggestAnalysis = async () => {
    const maestro = agents.find(a => a.role === 'Maestro')!;
    const apiKey = getApiKey(maestro.model.provider);
    if (!apiKey) {
        setApiKeyModalProvider(maestro.model.provider);
        return;
    }
    setIsSuggestingAnalysis(true);
    try {
      const ai = new GoogleGenAI(apiKey);
      const promptConfig = MAESTRO_SANDBOX_PROMPTS.SUGGEST_ANALYSIS;
      const fullTranscript = sessionLog.map(l => `${l.role}: ${l.content}`).join('\n');
      
      const result = await ai.getGenerativeModel({ model: maestro.model.modelName, systemInstruction: promptConfig.systemInstruction }).generateContent(fullTranscript);
      const { suggestions } = JSON.parse(result.response.text());
      setAnalysisSuggestions(suggestions);
    } catch (error) {
      console.error("Error suggesting analysis:", error);
    } finally {
      setIsSuggestingAnalysis(false);
    }
  };
  
  const handleGenerateAnalysis = async (prompt: string) => {
    const maestro = agents.find(a => a.role === 'Maestro')!;
    const apiKey = getApiKey(maestro.model.provider);
    if (!apiKey) {
        setApiKeyModalProvider(maestro.model.provider);
        return;
    }
    try {
      const ai = new GoogleGenAI(apiKey);
      const promptConfig = MAESTRO_SANDBOX_PROMPTS.GENERATE_ANALYSIS;
      const fullTranscript = sessionLog.map(l => `${l.role}: ${l.content}`).join('\n');
      const finalPrompt = `Analysis Prompt: "${prompt}"

Full Transcript:
${fullTranscript}`;
      
      const result = await ai.getGenerativeModel({ model: maestro.model.modelName, systemInstruction: promptConfig.systemInstruction }).generateContent(finalPrompt);
      setFinalDocument(result.response.text());
    } catch (error) {
      console.error("Error generating analysis:", error);
    }
  };


  const handleFileUpload = (newFiles: UploadedFile[]) => {
    setUploadedFiles(prev => [...prev, ...newFiles]);
  };

  const handleRemoveFile = (fileId: string) => {
    setUploadedFiles(prev => prev.filter(f => f.id !== fileId));
  };
  
  const scrollToLogEntry = (refId: string) => {
    document.getElementById(refId)?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  };

  return (
    <AppContext.Provider
      value={{
        activeMode, setActiveMode, showModeInfo, setShowModeInfo,
        agentConfigs, setAgentConfigs, agents, setAgents,
        isSessionActive, setIsSessionActive, sessionLog, setSessionLog,
        timelineEvents, setTimelineEvents, activeAgentId, setActiveAgentId,
        prevActiveAgentId, setPrevActiveAgentId, sessionGoal, setSessionGoal,
        finalDocument, setFinalDocument, uploadedFiles, setUploadedFiles,
        sessionControlRef,
        advisoryGoal, setAdvisoryGoal, isConsultingMaestro, setIsConsultingMaestro,
        itinerary, setItinerary, isItinerarySet, setIsItinerarySet,
        projectData, setProjectData, sandboxScenario, setSandboxScenario,
        isSandboxSetup, setIsSandboxSetup, analysisSuggestions, setAnalysisSuggestions,
        isSuggestingAnalysis, setIsSuggestingAnalysis,
        temperature, setTemperature, conversationTemperature, setConversationTemperature,
        outputFormat, setOutputFormat, apiKeyModalProvider, setApiKeyModalProvider, apiKeys,
        audioContextRef, activeAudioEntryId, setActiveAudioEntryId,
        currentlySpeakingAgent, setCurrentlySpeakingAgent, audioQueueRef, isPlayingRef,
        addLogEntry, handleStopAudio, handleStartSession, handleStopSession,
        handleUserMessage, handleModeChange, handleModeInfoClose, handleSaveApiKey,
        handleConsultMaestro, handleGenerateItinerary, handleSetupSandbox, handleSuggestAnalysis,
        handleGenerateAnalysis, handleFileUpload, handleRemoveFile, scrollToLogEntry,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useAppContext = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useAppContext must be used within an AppProvider');
  }
  return context;
};